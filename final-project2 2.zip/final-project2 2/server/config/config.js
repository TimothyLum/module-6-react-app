const env = process.env.NODE_ENV || 'development';

const config = {
    development: {
        port: process.env.PORT || 8080,
        dbURL: 'mongodb+srv://timothy:timothy00@cluster0.dn9cj.mongodb.net/kingsland-final',
        authCookieName: 'x-auth-token'
    },
    production: {}
};

module.exports = config[env];