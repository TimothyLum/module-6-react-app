const User = require('./User');
const Origami = require('./Origami');
const TokenBlacklist = require('./TokenBlacklist');

module.exports = {
    User,
    Origami,
    TokenBlacklist
};