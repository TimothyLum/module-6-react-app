export const getPosts = async (applyFunc) => {
  const url = "http://localhost:8080/api/origami";
  const res = await fetch(url);
  res.json().then((posts) => {
    applyFunc([...posts]);
  });
};
// const fetchPosts = async () => {
//     let res = await fetch("http://localhost:8080/api/origami")
// 	  res = await res.json();
// 	  setPosts(res)
//   }

export const login = async (username, password, applyFunc) => {
  const url = "http://localhost:8080/api/user/login";
  const body = JSON.stringify({ username, password });
  const headers = { "Content-Type": "application/json" };
  const res = await fetch(url, { method: "POST", body, headers });

  if (res.ok) {
    const result = await res.json();
    console.log(result);
    localStorage.setItem(
      "userData",
      JSON.stringify({
        token: result.token,
        id: result._id,
        username: result.username,
      })
    );
    applyFunc(true);
  } else {
    applyFunc(false);
  }
};
//   const login = async (username, password) =>{
//     let res = await fetch("http://localhost:8080/api/user/login",
// 		{method:'POST',
// 		headers: {"Content-Type": "application/json"},
// 		body: JSON.stringify({username, password})
// 		})
// 		res = await res.json();
//     console.log(res)
//     localStorage.setItem("userData", {token:res.token, id:res.user._id});
//     setIsAuth(true)
//   }

export const addPost = async (description, imageUrl) => {
  const { id, token } = JSON.parse(localStorage.getItem("userData"));
  const url = "http://localhost:8080/api/origami";
  const body = JSON.stringify({ description, author: id, imageUrl });
  const headers = {
    "Content-Type": "application/json",
    Authorization: `Bearer ${token}`,
  };
  const res = await fetch(url, { method: "POST", body, headers });
  console.log("this is res ", res);
  const result = await res.json();
  console.log("this is result ", result);

  return result;
};

export const register = async (username, password) => {
  const url = "http://localhost:8080/api/user/register";
  const body = JSON.stringify({ username, password });
  const headers = { "Content-Type": "application/json" };
  const res = await fetch(url, { method: "POST", body, headers });
  const result = await res.json();
  return result;
};

// export const logout = async () => {
//     const url = "http://localhost:8080/api/user/logout";
//     const { id, token } = JSON.parse(localStorage.getItem("userData"));
//     const headers = {
//               "Content-Type": "application/json",
//               Authorization: `Bearer ${token}`,
//     };
//     const res = await fetch(url, { method: "POST", body: '', headers });
//       const result = await res.json();
//     localStorage.removeItem("userData");
//     return result;

//   }

export const logout = () => {
  localStorage.removeItem("userData");
};
