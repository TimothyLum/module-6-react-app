import React from "react";
import PostAuthor from "./PostAuthor";

const Post = ({ post }) => {
  const { description, author } = post;

  return (
    <div className="postBlock">
      <img src="https://media.wired.com/photos/593261cab8eb31692072f129/master/pass/85120553.jpg" />
      <p className="text">Name: {description}</p>
      {/* <PostAuthor authorName={author} /> */}
    </div>
  );
};

export default Post;
