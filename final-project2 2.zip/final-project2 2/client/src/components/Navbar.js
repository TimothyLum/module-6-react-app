import "../assets/styles.css";
import React from "react";
import { useNavigate, NavLink } from "react-router-dom";
import { useContext } from "react";
import AuthContext from "../context/AuthContext";
import { logout } from "../services";

const Navbar = () => {
  const navigate = useNavigate();
  const { setIsAuth, isAuth } = useContext(AuthContext);

  // const logoutHandler = async () => {
  //   const res = await logout();
  //   console.log(res);
  //   setIsAuth(false);
  //   navigate("/");
  // };

  const activeLink = ({ isActive }) => {
    return {
      color: isActive ? "blue" : "inherit",
    };
  };
  let linksContent = (
    <>
      <li className="listItem">
        <NavLink style={activeLink} to="/">
          Home
        </NavLink>
      </li>
      <li className="listItem">
        <NavLink style={activeLink} to="/login">
          Login
        </NavLink>
      </li>
      <li className="listItem">
        <NavLink style={activeLink} to="/register">
          Register
        </NavLink>
      </li>
    </>
  );
  if (isAuth) {
    linksContent = (
      <>
        <li className="listItem">
          <NavLink style={activeLink} to="/">
            Home
          </NavLink>
        </li>
        <li className="listItem">
          <NavLink style={activeLink} to="/profile">
            Profile
          </NavLink>
        </li>
        <li className="listItem">
          <NavLink style={activeLink} to="/share">
            Post
          </NavLink>
        </li>
        {/* <li className="listItem">
          <button onClick={logoutHandler} id="logoutBtn">
            logout
          </button>
        </li> */}
      </>
    );
  }
  return (
    <div className="Navigation">
      <h1>Pet Society</h1>
      {linksContent}
    </div>
  );
};

export default Navbar;
