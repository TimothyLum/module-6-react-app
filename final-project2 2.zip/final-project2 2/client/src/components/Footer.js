import React from "react";
import "../assets/styles.css";
import { useNavigate, NavLink } from "react-router-dom";

const Footer = () => {
  return (
    <footer className="Footer">
      <ul>
        <li className="listItem">
          <NavLink to="/about">About Us</NavLink>
        </li>
        <li className="listItem">
          <NavLink to="/stories">Stories</NavLink>
        </li>
        <li className="listItem">
          <NavLink to="/contact">Contact</NavLink>
        </li>{" "}
        <li className="listItem">
          <NavLink to="/resources">Resources</NavLink>
        </li>
      </ul>
      <p>The Human Society of Hawaii &copy; 2022</p>
    </footer>
  );
};

export default Footer;
