import React, { useContext } from "react";
import AuthContext from "../context/AuthContext";
import "../assets/styles.css";
import { logout } from "../services";
import { useNavigate, NavLink } from "react-router-dom";

const AsideProfile = () => {
  const navigate = useNavigate();
  const { setIsAuth, isAuth } = useContext(AuthContext);

  const logoutHandler = async () => {
    const res = await logout();
    console.log(res);
    setIsAuth(false);
    navigate("/");
  };
  return (
    <card>
      <aside className="Aside">
        <div className="Profile">
          <img
            src="https://cdn.landesa.org/wp-content/uploads/default-user-image.png"
            alt="User pic"
          />
          <div className="personal-info">
            <p>
              <span>Email:</span> Filler{" "}
            </p>
            <p>
              {" "}
              <span>Photos</span> <span>Groups Link </span>{" "}
              <span>Articles Link </span> <span>Tricks Link</span>{" "}
            </p>
            <li className="listItem">
              <button onClick={logoutHandler} id="logoutBtn">
                logout
              </button>
            </li>
          </div>
        </div>
      </aside>
    </card>
  );
};

export default AsideProfile;
