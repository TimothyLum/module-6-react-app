import { useEffect, useState } from "react";
import { Routes, Route, Navigate } from "react-router-dom";
import Navbar from "./components/Navbar";
import Footer from "./components/Footer";
import Home from "./pages/Home";
import Login from "./pages/Login";
import Register from "./pages/Register";
import Profile from "./pages/Profile";
import Share from "./pages/Share";
import Error from "./pages/Error";
import PostsContext from "./context/Posts";
import AuthContext from "./context/AuthContext";
import { getPosts } from "./services";
import About from "./pages/About";
import Stories from "./pages/Stories";
import Resources from "./pages/Resources";
import Contact from "./pages/Contact";

function App() {
  const [posts, setPosts] = useState([]);
  const [isAuth, setIsAuth] = useState(localStorage.getItem("userData"));

  useEffect(() => {
    getPosts(setPosts);
  }, []);

  const logout = () => {
    localStorage.removeItem("userData");
    setIsAuth(false);
  };

  return (
    <AuthContext.Provider value={{ isAuth: isAuth, setIsAuth }}>
      <div className="App">
        <Navbar />
        <div className="container">
          <PostsContext.Provider value={{ posts: posts }}>
            <Routes>
              {!isAuth ? (
                <>
                  <Route path="/" element={<Home />} />
                  <Route path="/login" element={<Login />} />
                  <Route path="/register" element={<Register />} />
                </>
              ) : (
                <>
                  <Route path="/" element={<Home />} />
                  <Route path="/profile" element={<Profile />} />
                  <Route path="/share" element={<Share />} />
                </>
              )}
              <Route path="/about" element={<About />} />
              <Route path="/stories" element={<Stories />} />
              <Route path="/resources" element={<Resources />} />
              <Route path="/contact" element={<Contact />} />

              {/* <Route path="*" element={<Error />} /> */}
            </Routes>
          </PostsContext.Provider>
        </div>
        <Footer />
      </div>
    </AuthContext.Provider>
  );
}

export default App;
