import React from "react";
import "../assets/styles.css";

const Resources = () => {
  return <div className="Resources">Resources</div>;
};

export default Resources;
