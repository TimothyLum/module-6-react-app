import React from "react";
import "../assets/styles.css";
import AsideProfile from "../components/AsideProfile";

const Stories = () => {
  return (
    <div className="Stories">
      <AsideProfile />
      <div className="profileContainer">
        <h2>Latests articles</h2>

        <div>
          <h3>Title</h3>
          <p>Description&hellip;</p>
          <div>
            <a href="/details/">Read more</a>
          </div>
        </div>

        <h1>No articles, add one now.</h1>
      </div>
    </div>
  );
};

export default Stories;
