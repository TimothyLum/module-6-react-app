import React, { useContext, useState } from "react";
import { useNavigate } from "react-router-dom";
import "../assets/styles.css";
import PostsContext from "../context/Posts";
import { addPost } from "../services";

const Share = () => {
  const [post, setPost] = useState("");
  const { posts } = useContext(PostsContext);
  const navigate = useNavigate();

  const submitPost = async () => {
    const res = await addPost(post);
    // updatePosts();
    navigate("/profile");
  };
  return (
    <div className="Share">
      {/* -------- Goes to Home Page and Profile Album -------- */}

      <h1 className="titleShare">Share photos with friends! </h1>
      <div className="UserPost" onSubmit={submitPost}>
        <form method="POST">
          <div className="form-control">
            <label for="name">Description</label>
            <textarea
              id="name"
              name="description"
              onChange={(e) => setPost(e.target.value)}
              value={post}
            >
              {" "}
            </textarea>
          </div>
          <div className="form-control">
            <label for="image">ImageUrl</label>
            <input type="text" id="image" name="imageUrl" />
            <button type="submit">Submit</button>
          </div>
        </form>
      </div>

      {/* -------- Goes to stories -------- */}
      <h1 className="titleShare">Share your thoughts? </h1>
      <div className="UserPost" onSubmit={submitPost}>
        <form method="POST">
          <div className="form-control">
            <label for="title">Title</label>
            <input type="text" id="name" name="name" />
          </div>
          <div className="form-control">
            <label for="name">Content</label>
            <textarea
              id="name"
              name="description"
              onChange={(e) => setPost(e.target.value)}
              value={post}
            >
              {" "}
            </textarea>
          </div>
          <div className="form-control">
            <label for="image">ImageUrl</label>
            <input type="text" id="image" name="imageUrl" />
            <button type="submit">Submit</button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default Share;
