import React from "react";
import "../assets/styles.css";

const Contact = () => {
  return <div className="Contact">Contact</div>;
};

export default Contact;
