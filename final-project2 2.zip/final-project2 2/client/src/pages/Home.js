import React, { useContext } from "react";
import "../assets/styles.css";
import Posts from "../components/Posts";
import PostsContext from "../context/Posts";

const Home = () => {
  const { posts } = useContext(PostsContext);

  return (
    <div>
      <div className="postsContainer">
        <Posts posts={posts} />
      </div>
    </div>
  );
};

export default Home;
