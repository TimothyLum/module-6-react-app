import React, { useContext } from "react";
import AsideProfile from "../components/AsideProfile";
import Posts from "../components/Posts";
import PostsContext from "../context/Posts";

const Profile = () => {
  const { posts } = useContext(PostsContext);

  return (
    <div>
      <AsideProfile />
      <div className="profilePostsContainer">
        <h1>FRIENDS</h1>
        <div className="profilePosts">
          <Posts posts={posts} />
        </div>
      </div>
    </div>
  );
};

export default Profile;
