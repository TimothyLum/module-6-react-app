import React from 'react'
const Error = () => {
    return (
          <div className="FourOFour">
              <h1> Something Went Wrong ....</h1>
              <img
                  src="https://static8.depositphotos.com/1338574/829/i/600/depositphotos_8293069-stock-photo-sad-smiley-face-in-gold.jpg"
                  alt=""
              />
          </div>
      );
  }

export default Error